#include <iostream>
using namespace std;
//Registro de data.
struct dt
{
	int dia;
	int mes;
	int ano;
};

//Registro de emprestimo.
struct emp
{
	dt datadev;
	int matri;
	char idl[5];
	dt dataemp;
	double multa;
};

//Prototipos das fun��es.
void linha(char, int);

//Operator-
dt operator-(dt, dt);

//Operator cin.
istream& operator>>(istream&, dt&);

//Operator cout.
ostream& operator<<(ostream&, dt&);

void exibir(emp *, dt *, int);
