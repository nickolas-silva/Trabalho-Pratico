#include "biblioteca.h"
using namespace std;

//Fun��o que cria as linhas que separam o programa.
void linha(char t, int tam)
{
	for (int i = 0; i < tam; i++)
		cout << t;
	
}

//Fun��o operator- para fazer o calculo da diferen�a de dias entre variaveis do tipo dt.
dt operator-(dt dtdev, dt dtemp)
{
	dt teste;
	//Vetor com os dias de cada mes de janeiro a dezembro.
	const int diasm[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

	//Desincrementa��o para que os meses fiquem com a posi��o certa dentro do vetor de diasm.
	--dtdev.mes;
	--dtemp.mes;

	int tested1 =0;
	int tested2 = 0;

	//La�os para cotar quantos dias ja se passaram ate chegar no mes em quest�o que o usario digitou.
	for (int u = (dtdev.mes-1); u >= 0; u--)
		tested1 += diasm[u];
	for (int h = (dtemp.mes - 1); h >= 0; h--)
		tested2 += diasm[h];

	//Ao ter somado todos os dias dos meses anteriores ate aquele que o usuario digitou.
	//O numero de dias que o usuario digitou � somado a esse numero.
	teste.dia = (((tested1 + dtdev.dia) - (tested2 + dtemp.dia)));
	teste.mes = dtdev.mes - dtemp.mes;
	teste.ano = dtdev.ano - dtemp.ano;
	return teste;


	
}

//Fun��o cout para variaveis do tipo dt.
ostream& operator<<(ostream& os, dt &dma)
{
	os << dma.dia;
	os << dma.mes;
	os << dma.ano;
	return os;
}

//Fun��o para ler dia/mes/ano (data) para uma variavel do tipo dt (cin).
istream& operator>>(istream& is, dt &dma)
{
	is >> dma.dia;
	is.ignore();
	is >> dma.mes;
	is.ignore();
	is >> dma.ano;
	return is;

}

//Fun��o que exibi o resumo da matricula/codigo do livro/dia/mes/ano/multa dos emprestimos que foram digitados.
void exibir(emp * emp, dt * dev, int qnt)
{
	//Vetor de char para escrever o numero do mes por extenso.
	const char* meses[12] = { "Janeiro", "Fevereiro", "Mar�o", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro" };
	
	//Saida da frase resumo do dia.
	cout << "Resumo do dia ";
	cout.width(2);	cout.fill('0');
	cout << dev->dia << " de " << meses[dev->mes - 1] << " de " << dev->ano << endl;
	cout << endl;

	//La�o da fun��o exibir.
	for (int i = 0; i < qnt; i++)
	{
		cout << (emp+i)->matri << " " << (emp+i)->idl << " ";
		cout.width(2); cout.fill('0');
		cout <<  (emp+i)->dataemp.dia;
		cout << "/";
		cout.width(2); cout.fill('0');
		cout << (emp + i)->dataemp.mes << "/" << (emp + i)->dataemp.ano;
		cout << fixed; cout.precision(2);
		cout << " -> R$" << (emp + i)->multa << endl;
		
	}
}