#include "biblioteca.h"
using namespace std;

int main()
{
	int qnt;
	double multat = 0;
	
	// Declara��o do vetor dinamico.
	cout << "Qual o numero de devolucoes para hoje? ";
	cin >> qnt;
	emp * emprestimo = new emp[qnt];
	

	//Armazenamento da data de devolu��o.
	cout << "Qual a data de devolucao: ";
	dt datad;
	cin >> datad;
	

	//Fun��o para criar a primeira linha.
	linha('-', 44);

	//La�o principal
	for (int j = 0; j < qnt; j++)
	{
		cout << endl;

		//Armazenamento da matricula do aluno.
		cout << "Aluno     : ";
		cin >> emprestimo[j].matri;

		//Armazenamento do codigo do livro.
		cout << "Livro     : ";
		cin >> emprestimo[j].idl;

		//Armazenamento da data de emprestimo do livro.
		cout << "Emprestimo: ";
		cin >> emprestimo[j].dataemp;

		//Calculo e exibi��o do dias de atraso e do valor da multa.
		dt res = (datad - emprestimo[j].dataemp);
		
		//La�os para criar a logica de que ate 3 dias n�o existe atraso nem multa.
		while (res.dia == 3)
		{
			res.dia -= res.dia;
		}

		while (res.dia == 2)
		{
			res.dia -= res.dia;
		}

		while (res.dia == 1)
		{
			res.dia -= res.dia;
		}

		while (res.dia == 0)
		{
			cout << "Atraso    : " << (res.dia) << " dia(s)" << endl;
			emprestimo[j].multa = (res.dia * 0.80);
			res.dia--;
		}

		while (res.dia > 3)
		{
			cout << "Atraso    : " << (res.dia-3) << " dia(s)" << endl;
			emprestimo[j].multa = ((res.dia - 3) * 0.80);
			res.dia -= res.dia;
		}
		
		//Saida do valor da multa.
		multat += emprestimo[j].multa;
		cout << fixed; cout.precision(2);
		cout << "Multa     : R$" << emprestimo[j].multa << endl;
		//Linha que separa um emprestimo do outro.
		linha('-', 36);

	}
	linha('-', 8);
	cout << endl << endl;
	
	//Fun��o que exibi o resumo do dia.
	exibir(emprestimo, &datad, qnt);
	cout << endl;

	//Total de multas.
	cout << fixed; cout.precision(2);
	cout << "Total em multas: R$" << multat;
	cout << endl << endl;

	//Parte final do programa.
	linha('-', 44);
	cout << endl;
	cout << "Encerrando programa..." << endl;

	//Delete do vetor din�mico.
	delete[] emprestimo;
}